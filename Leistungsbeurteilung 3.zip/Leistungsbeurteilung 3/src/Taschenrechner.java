public class Taschenrechner
{

        public static int add(int a, int b)
        {
            return a+b;
        }

        public static int sub(int a, int b)
        {
            return a-b;
        }

        public static int div(int a, int b)
        {
            return a/b;
        }

        public static int mul(int a, int b)
        {
            return a*b;
        }

        public static double add1(double a, double b)
        {
            return a + b;
        }

        public static double sub1(double a, double b)
        {
            return a-b;
        }

        public static double mul1(double a, double b)
        {
            return a*b;
        }

        public static double div1(double a, double b)
        {
            return a/b;
        }

}
/*Meine Taschenrechner Methoden hierbei muss darauf geachtet werden das die Methoden nicht den selben Namen haben*/

